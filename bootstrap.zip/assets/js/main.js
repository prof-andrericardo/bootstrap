// 🧠 Script JS inicial
document.addEventListener('DOMContentLoaded', () => {
  console.log('Bootstrap pronto para uso!');
});